from django.apps import AppConfig


class DamageConfig(AppConfig):
    name = 'damage'
